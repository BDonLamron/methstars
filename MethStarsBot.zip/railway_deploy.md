# Railway Deployment Guide
# 1. Create a Railway project
# 2. Add your bot token as an environment variable (TELEGRAM_BOT_TOKEN)
# 3. Deploy using this project

# Make sure to use a persistent volume for data.json
