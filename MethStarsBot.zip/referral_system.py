# Referrals System
# Tracks how many users each person refers
# Adjusts price based on referral count

# Logic to store ref counts and apply price reductions in purchase
